import React from 'react';
import { Lightbulb, RotateCcw, ArrowRight, ArrowLeft, RefreshCw, Compass, Volume2, VolumeX, Eye } from 'lucide-react';

interface PuzzleControlsProps {
  onHint: () => void;
  hintLevel: number;
  onReset: () => void;
  onNextWebPuzzle: () => void;
  onOpenSearch: () => void;
  onFlipBoard: () => void;
  onToggleSound: () => void;
  isSoundEnabled: boolean;
  onToggleSolution: () => void;
  isShowingSolution: boolean;
  isLoadingNext: boolean;
  isSolved: boolean;
  canNextSolutionStep?: boolean;
  canPrevSolutionStep?: boolean;
  onNextSolutionStep?: () => void;
  onPrevSolutionStep?: () => void;
}

export const PuzzleControls: React.FC<PuzzleControlsProps> = ({
  onHint,
  hintLevel,
  onReset,
  onNextWebPuzzle,
  onOpenSearch,
  onFlipBoard,
  onToggleSound,
  isSoundEnabled,
  onToggleSolution,
  isShowingSolution,
  isLoadingNext,
  isSolved,
  canNextSolutionStep = false,
  canPrevSolutionStep = false,
  onNextSolutionStep,
  onPrevSolutionStep,
}) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 backdrop-blur-sm shadow-xl space-y-3">
      {/* Primary Action Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {/* Next Web Puzzle */}
        <button
          onClick={onNextWebPuzzle}
          disabled={isLoadingNext}
          className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg font-bold text-sm transition-all shadow-md active:scale-95 ${
            isSolved
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white ring-2 ring-emerald-400/50 animate-pulse'
              : 'bg-amber-600 hover:bg-amber-500 text-white'
          }`}
        >
          <RefreshCw className={`w-4 h-4 ${isLoadingNext ? 'animate-spin' : ''}`} />
          <span>{isLoadingNext ? 'جارِ البحث...' : isSolved ? 'اللغز التالي' : 'لغز من الويب'}</span>
        </button>

        {/* Hint Button */}
        <button
          onClick={onHint}
          disabled={isSolved || isShowingSolution}
          className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg font-bold text-sm transition-all border active:scale-95 ${
            hintLevel > 0
              ? 'bg-amber-950/60 border-amber-600/70 text-amber-300'
              : 'bg-slate-800/90 border-slate-700/80 hover:bg-slate-800 text-slate-200'
          } disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          <Lightbulb className={`w-4 h-4 ${hintLevel > 0 ? 'text-amber-400 fill-amber-400' : 'text-slate-400'}`} />
          <span>
            {hintLevel === 0 ? 'تلميح' : hintLevel === 1 ? 'إضاءة القطعة' : hintLevel === 2 ? 'إظهار النقلة' : 'تلميح كامل'}
          </span>
        </button>

        {/* Show Solution Walkthrough */}
        <button
          onClick={onToggleSolution}
          className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg font-bold text-sm transition-all border active:scale-95 ${
            isShowingSolution
              ? 'bg-sky-950/60 border-sky-600 text-sky-300'
              : 'bg-slate-800/90 border-slate-700/80 hover:bg-slate-800 text-slate-200'
          }`}
        >
          <Eye className="w-4 h-4 text-sky-400" />
          <span>{isShowingSolution ? 'إخفاء الحل' : 'عرض الحل'}</span>
        </button>

        {/* Reset / Try Again */}
        <button
          onClick={onReset}
          className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg font-bold text-sm bg-slate-800/90 hover:bg-slate-800 text-slate-200 border border-slate-700/80 transition-all active:scale-95"
        >
          <RotateCcw className="w-4 h-4 text-slate-400" />
          <span>إعادة التجربة</span>
        </button>
      </div>

      {/* Solution Walkthrough Steppers (Only visible when showing solution) */}
      {isShowingSolution && (
        <div className="flex items-center justify-between p-2.5 rounded-lg bg-sky-950/40 border border-sky-800/60">
          <span className="text-xs text-sky-300 font-semibold">استعراض خطوات الحل:</span>
          <div className="flex items-center gap-2">
            <button
              onClick={onPrevSolutionStep}
              disabled={!canPrevSolutionStep}
              className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed text-white text-xs flex items-center gap-1"
            >
              <ArrowRight className="w-3.5 h-3.5" />
              <span>السابق</span>
            </button>
            <button
              onClick={onNextSolutionStep}
              disabled={!canNextSolutionStep}
              className="p-1.5 rounded-md bg-sky-600 hover:bg-sky-500 disabled:opacity-30 disabled:cursor-not-allowed text-white text-xs flex items-center gap-1 font-bold"
            >
              <span>التالي</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Secondary Utilities Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80 text-xs text-slate-400">
        <button
          onClick={onOpenSearch}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-800/60 hover:bg-slate-800 text-slate-300 border border-slate-700/60 transition-colors"
        >
          <Compass className="w-3.5 h-3.5 text-amber-400" />
          <span>بحث واستكشاف الألغاز...</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Flip Board */}
          <button
            onClick={onFlipBoard}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-slate-800/60 hover:bg-slate-800 text-slate-300 border border-slate-700/60 transition-colors"
            title="قلب اتجاه الرقعة"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>قلب الرقعة</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-slate-800/60 hover:bg-slate-800 text-slate-300 border border-slate-700/60 transition-colors"
            title={isSoundEnabled ? 'كتم المؤثرات الصوتية' : 'تفعيل الصوت'}
          >
            {isSoundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">صوت: مفعل</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden sm:inline">صوت: صامت</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
