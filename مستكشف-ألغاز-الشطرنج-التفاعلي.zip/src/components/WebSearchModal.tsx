import React, { useState } from 'react';
import { Puzzle, PuzzleDifficulty, PuzzleTheme } from '../types/chess';
import { searchPuzzles, fetchChessComRandom, fetchLichessDaily, fetchChessComDaily, createCustomFenPuzzle } from '../services/puzzleFetcher';
import { getDifficultyLabelAr, getThemeLabelAr } from '../utils/chessFormatters';
import { Search, Globe, X, Sparkles, Filter, Code, Play, RefreshCw, Trophy } from 'lucide-react';

interface WebSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPuzzle: (puzzle: Puzzle) => void;
}

export const WebSearchModal: React.FC<WebSearchModalProps> = ({ isOpen, onClose, onSelectPuzzle }) => {
  const [activeTab, setActiveTab] = useState<'search' | 'liveWeb' | 'customFen'>('liveWeb');
  const [searchQuery, setSearchQuery] = useState('');
  const [difficulty, setDifficulty] = useState<PuzzleDifficulty>('all');
  const [theme, setTheme] = useState<PuzzleTheme>('all');
  const [searchResults, setSearchResults] = useState<Puzzle[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [customFenInput, setCustomFenInput] = useState('');
  const [customTitle, setCustomTitle] = useState('');
  const [fenError, setFenError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle immediate live web fetches
  const handleFetchWebRandom = async () => {
    setIsSearching(true);
    try {
      const puzzle = await fetchChessComRandom();
      if (puzzle) {
        onSelectPuzzle(puzzle);
        onClose();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleFetchLichessDaily = async () => {
    setIsSearching(true);
    try {
      const puzzle = await fetchLichessDaily();
      if (puzzle) {
        onSelectPuzzle(puzzle);
        onClose();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleFetchChessComDaily = async () => {
    setIsSearching(true);
    try {
      const puzzle = await fetchChessComDaily();
      if (puzzle) {
        onSelectPuzzle(puzzle);
        onClose();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  // Run catalog search
  const handleRunSearch = async () => {
    setIsSearching(true);
    try {
      const results = await searchPuzzles({
        query: searchQuery,
        difficulty,
        theme,
        source: 'all',
      });
      setSearchResults(results);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  // Load custom FEN
  const handleLoadCustomFen = () => {
    setFenError(null);
    try {
      if (!customFenInput.trim()) {
        setFenError('يرجى إدخال كود FEN صحيح');
        return;
      }
      const puzzle = createCustomFenPuzzle(customFenInput.trim(), customTitle);
      onSelectPuzzle(puzzle);
      onClose();
    } catch (err) {
      setFenError('كود FEN غير صالح. يرجى التحقق من الصيغة.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Globe className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold text-white">باحث ألغاز الشطرنج عبر الويب</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/50 text-xs sm:text-sm font-semibold">
          <button
            onClick={() => setActiveTab('liveWeb')}
            className={`flex-1 py-3 px-4 flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'liveWeb'
                ? 'border-amber-500 text-amber-400 bg-slate-900/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>ألغاز الويب المباشرة</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('search');
              if (searchResults.length === 0) handleRunSearch();
            }}
            className={`flex-1 py-3 px-4 flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'search'
                ? 'border-amber-500 text-amber-400 bg-slate-900/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>بحث مخصص وفلاتر</span>
          </button>

          <button
            onClick={() => setActiveTab('customFen')}
            className={`flex-1 py-3 px-4 flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'customFen'
                ? 'border-amber-500 text-amber-400 bg-slate-900/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>إدخال كود FEN</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* TAB 1: LIVE WEB FETCH */}
          {activeTab === 'liveWeb' && (
            <div className="space-y-4">
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                يقوم التطبيق بالاتصال بمصادر الويب المفتوحة ومواقع الشطرنج العالمية (بدون أي مفاتيح API أو رسوم) لجلب ألغاز تكتيكية حية:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Random Web Puzzle */}
                <button
                  onClick={handleFetchWebRandom}
                  disabled={isSearching}
                  className="p-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-amber-500/50 flex flex-col items-center text-center gap-2 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <RefreshCw className={`w-5 h-5 ${isSearching ? 'animate-spin' : ''}`} />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">لغز عشوائي من الويب</h4>
                    <p className="text-[11px] text-slate-400 mt-1">تحدي تكتيكي جديد في كل مرة</p>
                  </div>
                </button>

                {/* Lichess Daily */}
                <button
                  onClick={handleFetchLichessDaily}
                  disabled={isSearching}
                  className="p-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-amber-500/50 flex flex-col items-center text-center gap-2 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-sky-500/10 text-sky-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Trophy className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">لغز اليوم (Lichess)</h4>
                    <p className="text-[11px] text-slate-400 mt-1">لغز اليوم العالمي المعتمد</p>
                  </div>
                </button>

                {/* Chess.com Daily */}
                <button
                  onClick={handleFetchChessComDaily}
                  disabled={isSearching}
                  className="p-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-emerald-500/50 flex flex-col items-center text-center gap-2 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">لغز اليوم (Chess.com)</h4>
                    <p className="text-[11px] text-slate-400 mt-1">تحدي اليوم من شطرنج دوت كوم</p>
                  </div>
                </button>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-400 flex items-start gap-2.5">
                <span className="text-amber-400 font-bold">ملاحظة:</span>
                <span>
                  جميع الألغاز تجلب مباشرة من واجهات الويب الرسمية والمجانية دون تسجيل دخول ودون أي بطاقات ائتمان أو مفاتيح، مع التحقق الفوري من صحة النقلات.
                </span>
              </div>
            </div>
          )}

          {/* TAB 2: SEARCH & FILTER */}
          {activeTab === 'search' && (
            <div className="space-y-4">
              {/* Search Inputs */}
              <div className="space-y-3">
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleRunSearch()}
                    placeholder="ابحث باسم اللغز، اللاعب (مورفي، تال، كاسباروف) أو الفكرة التكتيكية..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 px-3.5 ps-10 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
                  />
                  <Search className="w-4 h-4 text-slate-400 absolute top-3.5 start-3.5 pointer-events-none" />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] text-slate-400 font-medium mb-1">
                      مستوى الصعوبة:
                    </label>
                    <select
                      value={difficulty}
                      onChange={(e) => setDifficulty(e.target.value as PuzzleDifficulty)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-amber-500"
                    >
                      <option value="all">جميع المستويات</option>
                      <option value="beginner">مبتدئ (&lt; 1200)</option>
                      <option value="intermediate">متوسط (1200 - 1600)</option>
                      <option value="advanced">متقدم (1600 - 2000)</option>
                      <option value="master">أستاذ شطرنج (&gt; 2000)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 font-medium mb-1">
                      الموضوع التكتيكي:
                    </label>
                    <select
                      value={theme}
                      onChange={(e) => setTheme(e.target.value as PuzzleTheme)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-xs text-white focus:outline-none focus:border-amber-500"
                    >
                      <option value="all">جميع التكتيكات</option>
                      <option value="mateIn1">كش مات في نقلة واحدة</option>
                      <option value="mateIn2">كش مات في نقلتين</option>
                      <option value="mateIn3">كش مات في 3 نقلات</option>
                      <option value="queenSacrifice">تضحية وزير ملحمية</option>
                      <option value="smotheredMate">كش مات مخنوق بالحصان</option>
                      <option value="fork">شوكة تكتيكية</option>
                      <option value="pin">ربط القطع</option>
                      <option value="discoveredAttack">هجوم بالكشف</option>
                    </select>
                  </div>
                </div>

                <button
                  onClick={handleRunSearch}
                  disabled={isSearching}
                  className="w-full py-2.5 px-4 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors"
                >
                  <Filter className="w-4 h-4" />
                  <span>تطبيق الفلترة والبحث</span>
                </button>
              </div>

              {/* Search Results List */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-xs text-slate-400 flex items-center justify-between">
                  <span>نتائج الألغاز ({searchResults.length})</span>
                </div>

                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {searchResults.map((p) => {
                    const diff = getDifficultyLabelAr(p.rating);
                    return (
                      <div
                        key={p.id}
                        onClick={() => {
                          onSelectPuzzle(p);
                          onClose();
                        }}
                        className="p-3 rounded-lg bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-amber-500/60 cursor-pointer transition-all flex items-center justify-between gap-3 group"
                      >
                        <div className="min-w-0">
                          <h5 className="font-bold text-white text-xs sm:text-sm truncate group-hover:text-amber-400 transition-colors">
                            {p.title}
                          </h5>
                          <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                            <span className={diff.colorClass}>{p.rating} Elo</span>
                            <span>·</span>
                            <span>{p.turn === 'w' ? 'الأبيض يلعب' : 'الأسود يلعب'}</span>
                            {p.themes?.[0] && (
                              <>
                                <span>·</span>
                                <span className="text-slate-300">{getThemeLabelAr(p.themes[0])}</span>
                              </>
                            )}
                          </div>
                        </div>

                        <button className="shrink-0 p-2 rounded-md bg-slate-800 group-hover:bg-amber-600 text-slate-300 group-hover:text-white transition-colors">
                          <Play className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CUSTOM FEN */}
          {activeTab === 'customFen' && (
            <div className="space-y-3.5">
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                هل لديك لغز من كتاب أو موقع شطرنج آخر؟ الصق كود FEN المكون للرقعة لتجربته وحله فوراً:
              </p>

              <div>
                <label className="block text-xs text-slate-300 font-bold mb-1">
                  عنوان اللغز (اختياري):
                </label>
                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  placeholder="مثال: لغز نهائي بطولة العالم..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-bold mb-1">
                  كود FEN:
                </label>
                <textarea
                  rows={3}
                  value={customFenInput}
                  onChange={(e) => setCustomFenInput(e.target.value)}
                  placeholder="مثال: 4kb1r/p2r1ppp/4qn2/1B2p1B1/4P3/1Q6/PPP2PPP/2KR4 w k - 2 15"
                  className="w-full font-mono bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-500 resize-none"
                />
              </div>

              {fenError && <p className="text-xs text-rose-400 font-medium">{fenError}</p>}

              <button
                onClick={handleLoadCustomFen}
                className="w-full py-2.5 px-4 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors"
              >
                <Play className="w-4 h-4" />
                <span>تحميل الموقف وبدء الحل</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
