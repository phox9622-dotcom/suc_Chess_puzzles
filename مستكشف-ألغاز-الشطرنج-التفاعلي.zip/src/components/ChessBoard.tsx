import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Chess, Square, Move } from 'chess.js';
import { BoardTheme, PieceColor, PieceType } from '../types/chess';
import { ChessPiece } from '../utils/chessPieces';
import { soundManager } from '../utils/audio';

interface ChessBoardProps {
  fen: string;
  theme: BoardTheme;
  orientation: PieceColor;
  onMovePlayed: (move: { from: string; to: string; promotion?: string; san: string }) => boolean;
  hintSquare?: string | null;
  hintTargetSquare?: string | null;
  wrongSquare?: string | null;
  isInteractive: boolean;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
const RANKS = ['8', '7', '6', '5', '4', '3', '2', '1'];

export const ChessBoard: React.FC<ChessBoardProps> = ({
  fen,
  theme,
  orientation,
  onMovePlayed,
  hintSquare,
  hintTargetSquare,
  wrongSquare,
  isInteractive,
}) => {
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [lastMove, setLastMove] = useState<{ from: string; to: string } | null>(null);
  const [pendingPromotion, setPendingPromotion] = useState<{ from: Square; to: Square } | null>(null);
  const [draggedSquare, setDraggedSquare] = useState<Square | null>(null);

  const chess = useMemo(() => {
    try {
      return new Chess(fen);
    } catch {
      return new Chess();
    }
  }, [fen]);

  // Find king square if in check
  const kingInCheckSquare = useMemo<Square | null>(() => {
    if (!chess.isCheck()) return null;
    const turn = chess.turn();
    const board = chess.board();
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece && piece.type === 'k' && piece.color === turn) {
          return `${FILES[c]}${8 - r}` as Square;
        }
      }
    }
    return null;
  }, [chess]);

  // Legal moves from selected square
  const legalMovesForSelected = useMemo<Move[]>(() => {
    if (!selectedSquare || !isInteractive) return [];
    try {
      return chess.moves({ square: selectedSquare, verbose: true });
    } catch {
      return [];
    }
  }, [chess, selectedSquare, isInteractive]);

  // Valid target squares map
  const legalTargetsMap = useMemo(() => {
    const map = new Map<string, { isCapture: boolean; move: Move }>();
    for (const m of legalMovesForSelected) {
      map.set(m.to, {
        isCapture: !!m.captured,
        move: m,
      });
    }
    return map;
  }, [legalMovesForSelected]);

  // Reset selection when FEN changes
  useEffect(() => {
    setSelectedSquare(null);
    setPendingPromotion(null);
  }, [fen]);

  // Handle square click
  const handleSquareClick = useCallback(
    (sq: Square) => {
      if (!isInteractive) return;

      const piece = chess.get(sq);
      const isCurrentPlayerTurn = chess.turn() === orientation;

      // If user clicked on a target square of currently selected piece
      if (selectedSquare && legalTargetsMap.has(sq)) {
        const targetInfo = legalTargetsMap.get(sq)!;
        const fromPiece = chess.get(selectedSquare);

        // Check if pawn promotion
        const isPromotion =
          fromPiece?.type === 'p' &&
          ((fromPiece.color === 'w' && sq.endsWith('8')) || (fromPiece.color === 'b' && sq.endsWith('1')));

        if (isPromotion) {
          setPendingPromotion({ from: selectedSquare, to: sq });
          return;
        }

        executeMove(selectedSquare, sq);
        return;
      }

      // If clicking own piece
      if (piece && piece.color === chess.turn() && isCurrentPlayerTurn) {
        setSelectedSquare(sq);
      } else {
        setSelectedSquare(null);
      }
    },
    [chess, isInteractive, legalTargetsMap, orientation, selectedSquare]
  );

  const executeMove = (from: Square, to: Square, promotion?: string) => {
    try {
      // Test move in temp instance
      const tempChess = new Chess(fen);
      const moveRes = tempChess.move({ from, to, promotion: promotion || 'q' });

      if (moveRes) {
        setLastMove({ from, to });
        setSelectedSquare(null);
        setPendingPromotion(null);

        const accepted = onMovePlayed({
          from,
          to,
          promotion,
          san: moveRes.san,
        });

        if (accepted) {
          if (moveRes.captured) {
            soundManager.playCapture();
          } else {
            soundManager.playMove();
          }
          if (tempChess.isCheck()) {
            soundManager.playCheck();
          }
        }
      }
    } catch (err) {
      console.warn('Illegal move attempted:', err);
    }
  };

  // Drag & drop handlers
  const handleDragStart = (e: React.DragEvent, sq: Square) => {
    if (!isInteractive) return;
    const piece = chess.get(sq);
    if (!piece || piece.color !== chess.turn() || piece.color !== orientation) {
      e.preventDefault();
      return;
    }
    setDraggedSquare(sq);
    setSelectedSquare(sq);
    e.dataTransfer.setData('text/plain', sq);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, toSq: Square) => {
    e.preventDefault();
    if (!draggedSquare || !isInteractive) return;

    if (legalTargetsMap.has(toSq)) {
      const fromPiece = chess.get(draggedSquare);
      const isPromotion =
        fromPiece?.type === 'p' &&
        ((fromPiece.color === 'w' && toSq.endsWith('8')) || (fromPiece.color === 'b' && toSq.endsWith('1')));

      if (isPromotion) {
        setPendingPromotion({ from: draggedSquare, to: toSq });
      } else {
        executeMove(draggedSquare, toSq);
      }
    }
    setDraggedSquare(null);
  };

  // Board grid orientation
  const displayRanks = orientation === 'w' ? RANKS : [...RANKS].reverse();
  const displayFiles = orientation === 'w' ? FILES : [...FILES].reverse();

  return (
    <div className="relative select-none aspect-square w-full max-w-[540px] mx-auto rounded-lg overflow-hidden shadow-2xl border-4 transition-colors duration-300 border-slate-800 bg-slate-900">
      {/* Board 8x8 Grid */}
      <div className="grid grid-cols-8 grid-rows-8 w-full h-full">
        {displayRanks.map((rank, rankIdx) =>
          displayFiles.map((file, fileIdx) => {
            const squareName = `${file}${rank}` as Square;
            const piece = chess.get(squareName);
            const isLight = (rankIdx + fileIdx) % 2 === 0;

            const isSelected = selectedSquare === squareName;
            const isLastMoveSquare = lastMove && (lastMove.from === squareName || lastMove.to === squareName);
            const isLegalTarget = legalTargetsMap.has(squareName);
            const targetDetails = legalTargetsMap.get(squareName);
            const isCaptureTarget = targetDetails?.isCapture;
            const isCheckSquare = kingInCheckSquare === squareName;
            const isHintSource = hintSquare === squareName;
            const isHintTarget = hintTargetSquare === squareName;
            const isWrong = wrongSquare === squareName;

            // Coordinates display
            const showRankCoord = orientation === 'w' ? fileIdx === 0 : fileIdx === 7;
            const showFileCoord = orientation === 'w' ? rankIdx === 7 : rankIdx === 0;

            return (
              <div
                key={squareName}
                onClick={() => handleSquareClick(squareName)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, squareName)}
                data-square={squareName}
                className={`relative flex items-center justify-center transition-all duration-100 ${
                  isLight ? theme.lightSquare : theme.darkSquare
                } ${isSelected ? theme.highlightSelected : ''} ${
                  isLastMoveSquare && !isSelected ? theme.highlightLastMove : ''
                } ${isCheckSquare ? 'ring-4 ring-inset ring-red-600 bg-red-500/30' : ''} ${
                  isHintSource ? 'ring-4 ring-inset ring-amber-400 bg-amber-300/40 animate-pulse' : ''
                } ${isHintTarget ? 'ring-4 ring-inset ring-emerald-400 bg-emerald-400/40 animate-pulse' : ''} ${
                  isWrong ? 'ring-4 ring-inset ring-rose-600 bg-rose-500/50 animate-bounce' : ''
                } cursor-pointer`}
              >
                {/* Coordinates Label */}
                {showRankCoord && (
                  <span
                    className={`absolute top-0.5 start-0.5 text-[10px] md:text-xs font-bold pointer-events-none select-none opacity-75 leading-none`}
                  >
                    {rank}
                  </span>
                )}
                {showFileCoord && (
                  <span
                    className={`absolute bottom-0.5 end-0.5 text-[10px] md:text-xs font-bold pointer-events-none select-none opacity-75 leading-none`}
                  >
                    {file}
                  </span>
                )}

                {/* Legal Move Dot Marker */}
                {isLegalTarget && !piece && (
                  <div className="absolute w-3.5 h-3.5 md:w-4 md:h-4 rounded-full bg-slate-900/35 ring-2 ring-slate-900/10 transition-transform scale-100" />
                )}

                {/* Capture Marker */}
                {isLegalTarget && piece && (
                  <div className="absolute inset-0 rounded-none ring-4 ring-inset ring-red-500/60 bg-red-500/20 pointer-events-none" />
                )}

                {/* Chess Piece SVG */}
                {piece && (
                  <div
                    draggable={isInteractive && piece.color === orientation && piece.color === chess.turn()}
                    onDragStart={(e) => handleDragStart(e, squareName)}
                    className={`w-[84%] h-[84%] flex items-center justify-center transition-transform hover:scale-105 active:scale-95 ${
                      piece.color === orientation && piece.color === chess.turn() ? 'cursor-grab active:cursor-grabbing' : ''
                    }`}
                  >
                    <ChessPiece type={piece.type} color={piece.color} />
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Pawn Promotion Modal */}
      {pendingPromotion && (
        <div className="absolute inset-0 z-30 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5 shadow-2xl text-center max-w-xs w-full animate-in fade-in zoom-in-95">
            <h4 className="text-amber-400 font-bold mb-3 text-base">ترقية البيدق (Promote)</h4>
            <div className="grid grid-cols-4 gap-2">
              {(['q', 'r', 'b', 'n'] as PieceType[]).map((pType) => (
                <button
                  key={pType}
                  onClick={() => executeMove(pendingPromotion.from, pendingPromotion.to, pType)}
                  className="aspect-square bg-slate-800 hover:bg-slate-700 active:bg-amber-600/30 border border-slate-600 rounded-lg p-2 flex items-center justify-center transition-all hover:scale-110"
                >
                  <ChessPiece type={pType} color={orientation} className="w-8 h-8" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
