import React from 'react';
import { Puzzle } from '../types/chess';
import { getDifficultyLabelAr, getThemeLabelAr } from '../utils/chessFormatters';
import { Globe, Trophy, Sparkles, User, Calendar, ExternalLink } from 'lucide-react';

interface PuzzleHeaderProps {
  puzzle: Puzzle;
  isSolved: boolean;
  stepIndex: number;
}

export const PuzzleHeader: React.FC<PuzzleHeaderProps> = ({ puzzle, isSolved, stepIndex }) => {
  const diff = getDifficultyLabelAr(puzzle.rating);
  const isWhiteTurn = puzzle.turn === 'w';

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 md:p-5 backdrop-blur-sm shadow-xl space-y-3">
      {/* Top Metadata Row: Source & Rating */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs md:text-sm text-slate-400">
        <div className="flex items-center gap-2">
          {puzzle.source === 'lichess' && (
            <span className="inline-flex items-center gap-1.5 text-amber-400 font-semibold">
              <Globe className="w-3.5 h-3.5" />
              <span>مباشر من Lichess API (مفتوح ومجاني)</span>
            </span>
          )}
          {puzzle.source === 'chesscom' && (
            <span className="inline-flex items-center gap-1.5 text-emerald-400 font-semibold">
              <Globe className="w-3.5 h-3.5" />
              <span>مباشر من Chess.com API (مفتوح ومجاني)</span>
            </span>
          )}
          {puzzle.source === 'masterpiece' && (
            <span className="inline-flex items-center gap-1.5 text-sky-400 font-semibold">
              <Trophy className="w-3.5 h-3.5" />
              <span>من روائع الشطرنج والبطولات العالمية</span>
            </span>
          )}
          {puzzle.source === 'custom' && (
            <span className="inline-flex items-center gap-1.5 text-purple-400 font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>لغز مخصص بواسطة كود FEN</span>
            </span>
          )}
          {puzzle.sourceUrl && (
            <a
              href={puzzle.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-500 hover:text-slate-300 transition-colors inline-flex items-center gap-0.5"
              title="عرض المصدر الأصلي"
            >
              <ExternalLink className="w-3 h-3" />
            </a>
          )}
        </div>

        <div className="flex items-center gap-3">
          <span className="font-mono text-slate-300 font-bold">
            تقييم اللغز: <span className={diff.colorClass}>{puzzle.rating} Elo</span>
          </span>
          <span className="text-slate-600">·</span>
          <span className={`${diff.colorClass} font-medium`}>{diff.label}</span>
        </div>
      </div>

      {/* Main Title & Objective */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1 border-t border-slate-800/80">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-white tracking-tight leading-snug">
            {puzzle.title}
          </h2>
          {puzzle.descriptionAr && (
            <p className="text-xs md:text-sm text-slate-400 mt-0.5 leading-relaxed">
              {puzzle.descriptionAr}
            </p>
          )}
        </div>

        {/* Turn Indicator Box */}
        <div className="shrink-0 flex items-center gap-2.5 px-3.5 py-2 rounded-lg bg-slate-800/90 border border-slate-700/60 shadow-inner">
          <div
            className={`w-4 h-4 rounded-full border border-slate-600 shadow-sm transition-transform ${
              isWhiteTurn ? 'bg-white ring-2 ring-white/30' : 'bg-slate-950 ring-2 ring-slate-800'
            }`}
          />
          <div className="text-xs md:text-sm">
            <div className="font-bold text-white">
              {isWhiteTurn ? 'دور الأبيض يلعب' : 'دور الأسود يلعب'}
            </div>
            <div className="text-[11px] text-amber-400 font-medium">
              {isSolved ? '✓ تم حل اللغز بنجاح!' : 'ابحث عن أفضل نقلة تكتيكية'}
            </div>
          </div>
        </div>
      </div>

      {/* Themes & Game Context */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 pt-1 text-xs text-slate-400">
        {puzzle.event && (
          <span className="inline-flex items-center gap-1 text-slate-400">
            <Calendar className="w-3 h-3 text-slate-500" />
            <span>{puzzle.event}</span>
          </span>
        )}
        {puzzle.players?.white && puzzle.players?.black && (
          <>
            <span className="text-slate-600">·</span>
            <span className="inline-flex items-center gap-1 text-slate-400">
              <User className="w-3 h-3 text-slate-500" />
              <span>
                {puzzle.players.white} ضد {puzzle.players.black}
              </span>
            </span>
          </>
        )}
        {puzzle.themes.length > 0 && (
          <>
            <span className="text-slate-600">·</span>
            <div className="inline-flex flex-wrap items-center gap-1.5 text-slate-400">
              <span className="text-slate-500">التصنيفات:</span>
              {puzzle.themes.map((t, idx) => (
                <span key={t} className="text-amber-300/90 font-medium">
                  {getThemeLabelAr(t)}
                  {idx < puzzle.themes.length - 1 ? '،' : ''}
                </span>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
