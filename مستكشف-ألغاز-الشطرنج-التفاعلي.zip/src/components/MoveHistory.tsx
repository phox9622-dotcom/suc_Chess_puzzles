import React from 'react';
import { CheckCircle2, AlertCircle, HelpCircle } from 'lucide-react';

interface MoveHistoryProps {
  playedMoves: string[];
  feedbackMessage: { text: string; type: 'success' | 'error' | 'info' } | null;
  hintMessage: string | null;
  isSolved: boolean;
}

export const MoveHistory: React.FC<MoveHistoryProps> = ({
  playedMoves,
  feedbackMessage,
  hintMessage,
  isSolved,
}) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 backdrop-blur-sm shadow-xl space-y-3">
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
        <h4 className="text-xs font-bold text-slate-300">سجل النقلات المنفذة</h4>
        <span className="text-[11px] font-mono text-slate-500">
          {playedMoves.length} {playedMoves.length === 1 ? 'نقلة' : 'نقلات'}
        </span>
      </div>

      {/* Moves List in SAN */}
      <div className="min-h-[44px] max-h-24 overflow-y-auto font-mono text-xs text-slate-300 flex flex-wrap gap-2 items-center">
        {playedMoves.length === 0 ? (
          <span className="text-slate-500 font-sans text-xs">
            قم بسحب أو النقر على قطعتك لتنفيذ النقلة الأولى...
          </span>
        ) : (
          playedMoves.map((m, idx) => {
            const moveNum = Math.floor(idx / 2) + 1;
            const isWhite = idx % 2 === 0;
            return (
              <span
                key={idx}
                className={`px-2 py-0.5 rounded text-xs font-bold ${
                  idx === playedMoves.length - 1
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-slate-800 text-slate-300'
                }`}
              >
                {isWhite ? `${moveNum}. ` : ''}
                {m}
              </span>
            );
          })
        )}
      </div>

      {/* Live Interactive Feedback Alert */}
      {feedbackMessage && (
        <div
          className={`flex items-start gap-2 p-2.5 rounded-lg text-xs font-medium border animate-in fade-in ${
            feedbackMessage.type === 'success'
              ? 'bg-emerald-950/50 border-emerald-700/60 text-emerald-300'
              : feedbackMessage.type === 'error'
              ? 'bg-rose-950/50 border-rose-700/60 text-rose-300'
              : 'bg-slate-800/60 border-slate-700 text-slate-300'
          }`}
        >
          {feedbackMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />}
          {feedbackMessage.type === 'error' && <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />}
          {feedbackMessage.type === 'info' && <HelpCircle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />}
          <span>{feedbackMessage.text}</span>
        </div>
      )}

      {/* Hint Message Box */}
      {hintMessage && !isSolved && (
        <div className="flex items-start gap-2 p-2.5 rounded-lg bg-amber-950/40 border border-amber-600/50 text-amber-200 text-xs">
          <HelpCircle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
          <div>
            <span className="font-bold block">إرشاد تكتيكي:</span>
            <span>{hintMessage}</span>
          </div>
        </div>
      )}

      {/* Solved Victory Banner */}
      {isSolved && (
        <div className="p-3 rounded-xl bg-gradient-to-r from-emerald-900/60 to-emerald-800/40 border border-emerald-500/60 text-center space-y-1">
          <div className="text-emerald-300 font-bold text-sm">✓ ممتاز جداً! تم حل اللغز بنجاح!</div>
          <p className="text-[11px] text-emerald-200/80">
            لقد أتقنت الفكرة التكتيكية. اضغط على "اللغز التالي" لاكتشاف تحدٍ جديد من الويب.
          </p>
        </div>
      )}
    </div>
  );
};
