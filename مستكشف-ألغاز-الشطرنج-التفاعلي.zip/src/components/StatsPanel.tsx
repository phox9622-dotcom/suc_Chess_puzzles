import React from 'react';
import { PlayerStats } from '../types/chess';
import { Flame, CheckCircle, Target, Clock } from 'lucide-react';

interface StatsPanelProps {
  stats: PlayerStats;
  elapsedSeconds: number;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({ stats, elapsedSeconds }) => {
  const accuracy = stats.attemptedCount > 0 ? Math.round((stats.solvedCount / stats.attemptedCount) * 100) : 100;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
      {/* Solved Counter */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
          <CheckCircle className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] text-slate-400">ألغاز محلولة</div>
          <div className="text-base font-bold text-white font-mono">{stats.solvedCount}</div>
        </div>
      </div>

      {/* Streak */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
          <Flame className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] text-slate-400">السلسلة الحالية</div>
          <div className="text-base font-bold text-amber-400 font-mono">
            {stats.currentStreak} <span className="text-[10px] text-slate-500">(أفضل: {stats.bestStreak})</span>
          </div>
        </div>
      </div>

      {/* Accuracy */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center shrink-0">
          <Target className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] text-slate-400">نسبة الدقة</div>
          <div className="text-base font-bold text-white font-mono">{accuracy}%</div>
        </div>
      </div>

      {/* Timer */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0">
          <Clock className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] text-slate-400">مؤقت التفكير</div>
          <div className="text-base font-bold text-purple-300 font-mono">{formatTime(elapsedSeconds)}</div>
        </div>
      </div>
    </div>
  );
};
