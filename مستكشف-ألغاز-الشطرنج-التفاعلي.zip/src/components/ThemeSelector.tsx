import React from 'react';
import { BoardThemeId } from '../types/chess';
import { BOARD_THEMES } from '../utils/boardThemes';
import { Palette } from 'lucide-react';

interface ThemeSelectorProps {
  currentThemeId: BoardThemeId;
  onSelectTheme: (id: BoardThemeId) => void;
}

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({ currentThemeId, onSelectTheme }) => {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-slate-400 font-medium hidden sm:inline-flex items-center gap-1">
        <Palette className="w-3.5 h-3.5 text-amber-400" />
        <span>طراز الرقعة:</span>
      </span>
      <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded-lg">
        {Object.values(BOARD_THEMES).map((theme) => {
          const isSelected = currentThemeId === theme.id;
          return (
            <button
              key={theme.id}
              onClick={() => onSelectTheme(theme.id)}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition-all ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title={theme.nameAr}
            >
              {theme.nameAr.split(' ')[0]}
            </button>
          );
        })}
      </div>
    </div>
  );
};
