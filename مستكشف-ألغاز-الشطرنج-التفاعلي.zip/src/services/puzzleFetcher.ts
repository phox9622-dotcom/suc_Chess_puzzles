import { Chess } from 'chess.js';
import { CURATED_PUZZLES } from '../data/curatedPuzzles';
import { PieceColor, Puzzle, PuzzleDifficulty, PuzzleTheme } from '../types/chess';
import { getThemeLabelAr } from '../utils/chessFormatters';

interface LichessDailyResponse {
  game: {
    id: string;
    perf?: { name: string };
    players?: { name: string; color: string; rating?: number }[];
    pgn?: string;
  };
  puzzle: {
    id: string;
    rating: number;
    plays: number;
    solution: string[];
    themes: string[];
    fen: string;
    lastMove?: string;
  };
}

interface ChessComDailyResponse {
  title: string;
  url: string;
  publish_time?: number;
  fen: string;
  pgn: string;
  image?: string;
}

/**
 * Extracts moves from PGN and verifies them against the starting FEN using chess.js
 */
export function extractMovesFromPgn(fen: string, pgn: string): string[] {
  try {
    const chess = new Chess(fen);
    const clean = pgn
      .replace(/\[[^\]]*\]/g, ' ')
      .replace(/\{[^}]*\}/g, ' ')
      .replace(/\d+\.{1,3}/g, ' ')
      .replace(/\*/g, ' ')
      .replace(/1-0|0-1|1\/2-1\/2/g, ' ')
      .trim();

    const tokens = clean.split(/\s+/).filter(Boolean);
    const validMoves: string[] = [];

    for (const token of tokens) {
      const res = chess.move(token);
      if (res) {
        validMoves.push(res.san);
      }
    }
    return validMoves;
  } catch (err) {
    console.error('Error extracting moves from PGN:', err);
    return [];
  }
}

/**
 * Converts UCI moves (e.g. "e2e4", "e7e8q") into standard algebraic notation (SAN)
 */
export function convertUciToSanMoves(fen: string, uciMoves: string[]): string[] {
  try {
    const chess = new Chess(fen);
    const validMoves: string[] = [];

    for (const uci of uciMoves) {
      if (!uci || uci.length < 4) continue;
      const from = uci.slice(0, 2);
      const to = uci.slice(2, 4);
      const promotion = uci.length > 4 ? uci.slice(4, 5).toLowerCase() : undefined;

      const res = chess.move({ from, to, promotion });
      if (res) {
        validMoves.push(res.san);
      }
    }
    return validMoves;
  } catch (err) {
    console.error('Error converting UCI moves:', err);
    return [];
  }
}

/**
 * Fetches the daily puzzle from Lichess public API (No API key needed)
 */
export async function fetchLichessDaily(): Promise<Puzzle | null> {
  try {
    const res = await fetch('https://lichess.org/api/puzzle/daily', {
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) throw new Error(`Lichess API returned ${res.status}`);
    const data: LichessDailyResponse = await res.json();

    const fen = data.puzzle.fen;
    const chess = new Chess(fen);
    const turn = chess.turn() as PieceColor;
    const sanSolution = convertUciToSanMoves(fen, data.puzzle.solution);

    if (sanSolution.length === 0) {
      throw new Error('Could not parse Lichess puzzle solution');
    }

    const whitePlayer = data.game.players?.find((p) => p.color === 'white');
    const blackPlayer = data.game.players?.find((p) => p.color === 'black');

    const primaryTheme = data.puzzle.themes?.[0] || 'tactics';
    const primaryThemeAr = getThemeLabelAr(primaryTheme);

    return {
      id: `lichess_${data.puzzle.id}`,
      source: 'lichess',
      title: `لغز اليوم العالمي من Lichess (${primaryThemeAr})`,
      titleEn: `Lichess Daily Puzzle #${data.puzzle.id}`,
      descriptionAr: `لغز شطرنج مباشر من موقع Lichess العالمي. التقييم التقديري: ${data.puzzle.rating} نقطة.`,
      descriptionEn: `Live daily puzzle from Lichess open database. Rating: ${data.puzzle.rating}.`,
      fen,
      solution: sanSolution,
      rating: data.puzzle.rating || 1500,
      themes: data.puzzle.themes || ['tactics'],
      turn,
      plays: data.puzzle.plays,
      sourceUrl: `https://lichess.org/training/${data.puzzle.id}`,
      players: {
        white: whitePlayer?.name || 'لاعب أبيض',
        black: blackPlayer?.name || 'لاعب أسود',
        whiteRating: whitePlayer?.rating,
        blackRating: blackPlayer?.rating,
      },
      event: `Lichess Daily Puzzle`,
    };
  } catch (error) {
    console.warn('Lichess daily puzzle fetch failed:', error);
    return null;
  }
}

/**
 * Fetches the daily puzzle from Chess.com public API (No API key needed)
 */
export async function fetchChessComDaily(): Promise<Puzzle | null> {
  try {
    const res = await fetch('https://api.chess.com/pub/puzzle', {
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) throw new Error(`Chess.com API returned ${res.status}`);
    const data: ChessComDailyResponse = await res.json();

    const fen = data.fen;
    const chess = new Chess(fen);
    const turn = chess.turn() as PieceColor;
    const solution = extractMovesFromPgn(fen, data.pgn);

    if (solution.length === 0) {
      throw new Error('Could not parse Chess.com solution');
    }

    return {
      id: `chesscom_${data.url.split('/').pop() || Date.now()}`,
      source: 'chesscom',
      title: `لغز اليوم من موقع Chess.com: "${data.title || 'تحدي تكتيكي'}"`,
      titleEn: `Chess.com Daily: ${data.title}`,
      descriptionAr: `لغز شطرنج تكتيكي مباشر من موقع شطرنج دوت كوم اليومي.`,
      descriptionEn: `Live daily puzzle from Chess.com.`,
      fen,
      solution,
      rating: 1600,
      themes: ['mateIn2', 'sacrifice'],
      turn,
      sourceUrl: data.url,
      event: 'Chess.com Daily Puzzle',
    };
  } catch (error) {
    console.warn('Chess.com daily puzzle fetch failed:', error);
    return null;
  }
}

/**
 * Fetches a random live puzzle from Chess.com public archives (No API key needed)
 */
export async function fetchChessComRandom(): Promise<Puzzle | null> {
  try {
    const res = await fetch('https://api.chess.com/pub/puzzle/random', {
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) throw new Error(`Chess.com random API returned ${res.status}`);
    const data: ChessComDailyResponse = await res.json();

    const fen = data.fen;
    const chess = new Chess(fen);
    const turn = chess.turn() as PieceColor;
    const solution = extractMovesFromPgn(fen, data.pgn);

    if (solution.length === 0) {
      throw new Error('Could not parse solution');
    }

    return {
      id: `chesscom_rnd_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      source: 'chesscom',
      title: `لغز شطرنج عشوائي من الويب: "${data.title || 'مغامرة تكتيكية'}"`,
      titleEn: `Web Puzzle: ${data.title}`,
      descriptionAr: `تم العثور على هذا اللغز مباشرة من أرشيف الويب المفتوح لشطرنج دوت كوم.`,
      descriptionEn: `Fetched randomly from open online chess database.`,
      fen,
      solution,
      rating: 1550,
      themes: ['tactics', 'deflection'],
      turn,
      sourceUrl: data.url,
      event: 'أرشيف ألغاز الويب المفتوحة',
    };
  } catch (error) {
    console.warn('Chess.com random puzzle fetch failed:', error);
    return null;
  }
}

/**
 * Search and filter puzzles across live web APIs and curated library
 */
export async function searchPuzzles(params: {
  query?: string;
  difficulty?: PuzzleDifficulty;
  theme?: PuzzleTheme;
  source?: 'all' | 'web' | 'lichess' | 'chesscom' | 'masterpiece';
}): Promise<Puzzle[]> {
  const { query = '', difficulty = 'all', theme = 'all', source = 'all' } = params;

  let results: Puzzle[] = [...CURATED_PUZZLES];

  // If user explicitly asks for web or all, fetch live web puzzles
  if (source === 'all' || source === 'web' || source === 'lichess') {
    const lichessPuzzle = await fetchLichessDaily();
    if (lichessPuzzle) {
      results.unshift(lichessPuzzle);
    }
  }

  if (source === 'all' || source === 'web' || source === 'chesscom') {
    const chessComPuzzle = await fetchChessComDaily();
    if (chessComPuzzle) {
      results.unshift(chessComPuzzle);
    }
  }

  // Filter by source
  if (source !== 'all') {
    if (source === 'web') {
      results = results.filter((p) => p.source === 'lichess' || p.source === 'chesscom' || p.source === 'web');
    } else {
      results = results.filter((p) => p.source === source);
    }
  }

  // Filter by difficulty
  if (difficulty !== 'all') {
    results = results.filter((p) => {
      if (difficulty === 'beginner') return p.rating < 1200;
      if (difficulty === 'intermediate') return p.rating >= 1200 && p.rating < 1600;
      if (difficulty === 'advanced') return p.rating >= 1600 && p.rating < 2000;
      if (difficulty === 'master') return p.rating >= 2000;
      return true;
    });
  }

  // Filter by theme
  if (theme !== 'all') {
    results = results.filter((p) => p.themes.includes(theme));
  }

  // Filter by text query
  if (query.trim()) {
    const q = query.toLowerCase().trim();
    results = results.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        (p.titleEn && p.titleEn.toLowerCase().includes(q)) ||
        (p.descriptionAr && p.descriptionAr.toLowerCase().includes(q)) ||
        (p.event && p.event.toLowerCase().includes(q)) ||
        (p.players?.white && p.players.white.toLowerCase().includes(q)) ||
        (p.players?.black && p.players.black.toLowerCase().includes(q)) ||
        p.themes.some((t) => t.toLowerCase().includes(q) || getThemeLabelAr(t).toLowerCase().includes(q))
    );
  }

  return results;
}

/**
 * Validates and creates a custom puzzle from a user-supplied FEN
 */
export function createCustomFenPuzzle(fen: string, title?: string, solutionString?: string): Puzzle {
  const chess = new Chess(fen);
  const turn = chess.turn() as PieceColor;

  let solution: string[] = [];
  if (solutionString && solutionString.trim()) {
    solution = extractMovesFromPgn(fen, solutionString);
  }

  return {
    id: `custom_${Date.now()}`,
    source: 'custom',
    title: title?.trim() || 'لغز شطرنج مخصص من كود FEN',
    titleEn: 'Custom FEN Chess Puzzle',
    descriptionAr: `موقف شطرنج مخصص تم جلبه من كود FEN.`,
    fen: chess.fen(),
    solution,
    rating: 1500,
    themes: ['custom'],
    turn,
  };
}
