export const THEME_TRANSLATIONS: Record<string, { ar: string; en: string }> = {
  mateIn1: { ar: 'كش مات في نقلة واحدة', en: 'Mate in 1' },
  mateIn2: { ar: 'كش مات في نقلتين', en: 'Mate in 2' },
  mateIn3: { ar: 'كش مات في 3 نقلات', en: 'Mate in 3' },
  mateIn4: { ar: 'كش مات في 4 نقلات', en: 'Mate in 4' },
  mateIn5: { ar: 'كش مات في 5 نقلات', en: 'Mate in 5' },
  queenSacrifice: { ar: 'تضحية وزير ملحمية', en: 'Queen Sacrifice' },
  sacrifice: { ar: 'تضحية تكتيكية', en: 'Sacrifice' },
  fork: { ar: 'شوكة بالحصان أو البيدق', en: 'Fork' },
  pin: { ar: 'ربط القطع (Pin)', en: 'Pin' },
  skewer: { ar: 'سيخ تكتيكي (Skewer)', en: 'Skewer' },
  discoveredAttack: { ar: 'هجوم بالكشف', en: 'Discovered Attack' },
  doubleCheck: { ar: 'كش مزدوج', en: 'Double Check' },
  smotheredMate: { ar: 'كش مات مخنوق بالحصان', en: 'Smothered Mate' },
  backRankMate: { ar: 'مات الصف الخلفي', en: 'Back-Rank Mate' },
  anastasiaMate: { ar: 'كش مات أناستازيا', en: 'Anastasia Mate' },
  arabianMate: { ar: 'كش مات عربي (رخ وحصان)', en: 'Arabian Mate' },
  bodensMate: { ar: 'كش مات بودن (بزوج فيلة)', en: 'Boden Mate' },
  deflection: { ar: 'تشتيت حامي القطعة', en: 'Deflection' },
  attraction: { ar: 'استدراج ملك الخصم', en: 'Attraction' },
  clearance: { ar: 'تفريغ مسار الهجوم', en: 'Clearance' },
  intermezzo: { ar: 'نقلة بينية مفاجئة', en: 'Zwischenzug / In-Between' },
  interference: { ar: 'قطع خطوط الاتصال', en: 'Interference' },
  overloading: { ar: 'إرهاق القطعة المدافعة', en: 'Overloading' },
  endgame: { ar: 'تكتيك نهايات أدوار', en: 'Endgame' },
  rookEndgame: { ar: 'نهايات رخاخ', en: 'Rook Endgame' },
  pawnEndgame: { ar: 'نهايات بيادق وترقية', en: 'Pawn Endgame' },
  short: { ar: 'تكتيك حاسم وسريع', en: 'Short Tactic' },
  long: { ar: 'تكتيك استراتيجي عميق', en: 'Long Tactic' },
  crushing: { ar: 'هجوم ساحق', en: 'Crushing Advantage' },
  masterpiece: { ar: 'أحد روائع الشطرنج الخالدة', en: 'Historical Masterpiece' },
};

export function getThemeLabelAr(themeKey: string): string {
  const normalized = themeKey.replace(/[-_]/g, '');
  for (const [k, v] of Object.entries(THEME_TRANSLATIONS)) {
    if (k.toLowerCase() === normalized.toLowerCase() || k.toLowerCase() === themeKey.toLowerCase()) {
      return v.ar;
    }
  }
  return themeKey;
}

export function getDifficultyLabelAr(rating: number): { label: string; colorClass: string; level: string } {
  if (rating < 1200) {
    return { label: 'مبتدئ (Beginner)', colorClass: 'text-emerald-400', level: 'beginner' };
  } else if (rating < 1600) {
    return { label: 'متوسط (Intermediate)', colorClass: 'text-sky-400', level: 'intermediate' };
  } else if (rating < 2000) {
    return { label: 'متقدم (Advanced)', colorClass: 'text-amber-400', level: 'advanced' };
  } else {
    return { label: 'أستاذ شطرنج (Master)', colorClass: 'text-rose-400', level: 'master' };
  }
}

export function getPieceNameAr(pieceChar: string): string {
  const lower = pieceChar.toLowerCase();
  switch (lower) {
    case 'p': return 'البيدق';
    case 'n': return 'الحصان';
    case 'b': return 'الفيل';
    case 'r': return 'الرخ (القلعة)';
    case 'q': return 'الوزير';
    case 'k': return 'الملك';
    default: return 'القطعة';
  }
}
