export type PieceColor = 'w' | 'b';
export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';

export type BoardThemeId = 'classic-wood' | 'tournament-green' | 'midnight-blue' | 'royal-amber' | 'dark-slate';

export interface BoardTheme {
  id: BoardThemeId;
  nameAr: string;
  nameEn: string;
  lightSquare: string;
  darkSquare: string;
  border: string;
  highlightLastMove: string;
  highlightSelected: string;
  highlightLegalDot: string;
  highlightCapture: string;
}

export type PuzzleDifficulty = 'all' | 'beginner' | 'intermediate' | 'advanced' | 'master';

export type PuzzleTheme =
  | 'all'
  | 'mateIn1'
  | 'mateIn2'
  | 'mateIn3'
  | 'queenSacrifice'
  | 'fork'
  | 'pin'
  | 'discoveredAttack'
  | 'smotheredMate'
  | 'endgame'
  | 'deflection';

export interface Puzzle {
  id: string;
  source: 'lichess' | 'chesscom' | 'masterpiece' | 'custom' | 'web';
  title: string;
  titleEn?: string;
  descriptionAr?: string;
  descriptionEn?: string;
  fen: string;
  /** Solution moves in sequence. Can be UCI (e.g. "e2e4") or SAN (e.g. "Nf3+") */
  solution: string[];
  rating: number;
  themes: string[];
  turn: PieceColor;
  plays?: number;
  sourceUrl?: string;
  players?: {
    white?: string;
    black?: string;
    whiteRating?: number;
    blackRating?: number;
  };
  event?: string;
  year?: number | string;
}

export interface MoveStep {
  ply: number;
  san: string;
  from: string;
  to: string;
  piece: PieceType;
  color: PieceColor;
  captured?: PieceType;
  promotion?: string;
}

export interface PlayerStats {
  solvedCount: number;
  attemptedCount: number;
  currentStreak: number;
  bestStreak: number;
  hintsUsed: number;
  history: {
    puzzleId: string;
    title: string;
    rating: number;
    solved: boolean;
    timestamp: number;
    timeTakenSeconds: number;
  }[];
}
