import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Chess, Square } from 'chess.js';
import confetti from 'canvas-confetti';
import { CURATED_PUZZLES } from './data/curatedPuzzles';
import { BoardThemeId, PieceColor, PlayerStats, Puzzle } from './types/chess';
import { BOARD_THEMES } from './utils/boardThemes';
import { soundManager } from './utils/audio';
import { getPieceNameAr } from './utils/chessFormatters';
import { fetchChessComRandom, fetchLichessDaily } from './services/puzzleFetcher';
import { ChessBoard } from './components/ChessBoard';
import { PuzzleHeader } from './components/PuzzleHeader';
import { PuzzleControls } from './components/PuzzleControls';
import { MoveHistory } from './components/MoveHistory';
import { StatsPanel } from './components/StatsPanel';
import { ThemeSelector } from './components/ThemeSelector';
import { WebSearchModal } from './components/WebSearchModal';
import { Trophy, Globe, Sparkles, Volume2, VolumeX, ShieldCheck } from 'lucide-react';

const INITIAL_STATS: PlayerStats = {
  solvedCount: 0,
  attemptedCount: 0,
  currentStreak: 0,
  bestStreak: 0,
  hintsUsed: 0,
  history: [],
};

export default function App() {
  const [puzzle, setPuzzle] = useState<Puzzle>(CURATED_PUZZLES[0]);
  const [boardFen, setBoardFen] = useState<string>(CURATED_PUZZLES[0].fen);
  const [orientation, setOrientation] = useState<PieceColor>(CURATED_PUZZLES[0].turn);
  const [themeId, setThemeId] = useState<BoardThemeId>('tournament-green');

  const [playedMoves, setPlayedMoves] = useState<string[]>([]);
  const [solutionStepIndex, setSolutionStepIndex] = useState<number>(0);
  const [isSolved, setIsSolved] = useState<boolean>(false);
  const [isInteractive, setIsInteractive] = useState<boolean>(true);

  // Hints & Visual cues
  const [hintLevel, setHintLevel] = useState<number>(0);
  const [hintSquare, setHintSquare] = useState<string | null>(null);
  const [hintTargetSquare, setHintTargetSquare] = useState<string | null>(null);
  const [hintMessage, setHintMessage] = useState<string | null>(null);
  const [wrongSquare, setWrongSquare] = useState<string | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Solution Walkthrough mode
  const [isShowingSolution, setIsShowingSolution] = useState<boolean>(false);
  const [walkthroughIndex, setWalkthroughIndex] = useState<number>(0);
  const [walkthroughPositions, setWalkthroughPositions] = useState<string[]>([]);

  // Search & Web
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isLoadingNext, setIsLoadingNext] = useState<boolean>(false);
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(true);

  // Stats & Timer
  const [stats, setStats] = useState<PlayerStats>(() => {
    try {
      const saved = localStorage.getItem('chess_puzzles_stats');
      return saved ? JSON.parse(saved) : INITIAL_STATS;
    } catch {
      return INITIAL_STATS;
    }
  });
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Save stats to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('chess_puzzles_stats', JSON.stringify(stats));
    } catch {
      // Storage unavailable
    }
  }, [stats]);

  // Timer runner
  useEffect(() => {
    if (isSolved || isShowingSolution) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isSolved, isShowingSolution]);

  // Attempt to load live daily puzzle on initial mount
  useEffect(() => {
    let isMounted = true;
    const loadDaily = async () => {
      try {
        const livePuzzle = await fetchLichessDaily();
        if (livePuzzle && isMounted) {
          loadNewPuzzle(livePuzzle);
        }
      } catch {
        // Fallback to initial curated puzzle
      }
    };
    loadDaily();
    return () => {
      isMounted = false;
    };
  }, []);

  // Precompute walkthrough positions when puzzle changes
  const computeWalkthroughPositions = useCallback((p: Puzzle) => {
    try {
      const c = new Chess(p.fen);
      const positions: string[] = [p.fen];
      for (const m of p.solution) {
        c.move(m);
        positions.push(c.fen());
      }
      setWalkthroughPositions(positions);
    } catch {
      setWalkthroughPositions([p.fen]);
    }
  }, []);

  // Load a new puzzle
  const loadNewPuzzle = useCallback((newPuzzle: Puzzle) => {
    setPuzzle(newPuzzle);
    setBoardFen(newPuzzle.fen);
    setOrientation(newPuzzle.turn);
    setPlayedMoves([]);
    setSolutionStepIndex(0);
    setIsSolved(false);
    setIsInteractive(true);
    setHintLevel(0);
    setHintSquare(null);
    setHintTargetSquare(null);
    setHintMessage(null);
    setWrongSquare(null);
    setFeedbackMessage(null);
    setIsShowingSolution(false);
    setWalkthroughIndex(0);
    setElapsedSeconds(0);
    computeWalkthroughPositions(newPuzzle);
  }, [computeWalkthroughPositions]);

  // Reset current puzzle
  const handleResetPuzzle = useCallback(() => {
    setBoardFen(puzzle.fen);
    setPlayedMoves([]);
    setSolutionStepIndex(0);
    setIsSolved(false);
    setIsInteractive(true);
    setHintLevel(0);
    setHintSquare(null);
    setHintTargetSquare(null);
    setHintMessage(null);
    setWrongSquare(null);
    setFeedbackMessage(null);
    setIsShowingSolution(false);
    setWalkthroughIndex(0);
    setElapsedSeconds(0);
  }, [puzzle]);

  // Fetch next live puzzle from web
  const handleFetchNextWebPuzzle = async () => {
    setIsLoadingNext(true);
    try {
      // Alternate or random fetch from web
      const randomPuzzle = await fetchChessComRandom();
      if (randomPuzzle) {
        loadNewPuzzle(randomPuzzle);
      } else {
        // Fallback to next curated puzzle
        const nextIdx = (CURATED_PUZZLES.findIndex((p) => p.id === puzzle.id) + 1) % CURATED_PUZZLES.length;
        loadNewPuzzle(CURATED_PUZZLES[nextIdx]);
      }
    } catch {
      const nextIdx = (CURATED_PUZZLES.findIndex((p) => p.id === puzzle.id) + 1) % CURATED_PUZZLES.length;
      loadNewPuzzle(CURATED_PUZZLES[nextIdx]);
    } finally {
      setIsLoadingNext(false);
    }
  };

  // Sound toggle
  const handleToggleSound = () => {
    soundManager.enabled = !soundManager.enabled;
    setIsSoundEnabled(soundManager.enabled);
  };

  // Hint button logic
  const handleHint = () => {
    if (isSolved || solutionStepIndex >= puzzle.solution.length) return;

    soundManager.playHint();
    const nextLevel = hintLevel + 1;
    setHintLevel(nextLevel);

    const expectedSan = puzzle.solution[solutionStepIndex];
    const currentChess = new Chess(boardFen);
    const moveObj = currentChess.move(expectedSan);

    if (!moveObj) return;

    const fromSquare = moveObj.from;
    const toSquare = moveObj.to;
    const pieceName = getPieceNameAr(moveObj.piece);

    if (nextLevel === 1) {
      setHintMessage(`فكر في حركة قوية باستخدام ${pieceName}.`);
      setFeedbackMessage({
        text: `تلميح 1: القطعة المستهدفة هي ${pieceName}.`,
        type: 'info',
      });
    } else if (nextLevel === 2) {
      setHintSquare(fromSquare);
      setHintMessage(`القطعة المطلوبة هي ${pieceName} في المربع ${fromSquare.toUpperCase()}.`);
      setFeedbackMessage({
        text: `تلميح 2: تم تمييز المربع ${fromSquare.toUpperCase()} باللون الذهبي.`,
        type: 'info',
      });
    } else {
      setHintSquare(fromSquare);
      setHintTargetSquare(toSquare);
      setHintMessage(`النقلة الصحيحة هي ${expectedSan} (من ${fromSquare.toUpperCase()} إلى ${toSquare.toUpperCase()}).`);
      setFeedbackMessage({
        text: `تلميح 3: انقل ${pieceName} إلى ${toSquare.toUpperCase()}.`,
        type: 'info',
      });
    }

    setStats((prev) => ({ ...prev, hintsUsed: prev.hintsUsed + 1 }));
  };

  // Toggle solution walkthrough
  const handleToggleSolution = () => {
    if (!isShowingSolution) {
      setIsShowingSolution(true);
      setIsInteractive(false);
      setWalkthroughIndex(0);
      setBoardFen(walkthroughPositions[0] || puzzle.fen);
      setFeedbackMessage({
        text: 'وضع استعراض الحل: استخدم أزرار السابق والتالي لمشاهدة النقلات.',
        type: 'info',
      });
    } else {
      setIsShowingSolution(false);
      setIsInteractive(true);
      handleResetPuzzle();
    }
  };

  const handleNextSolutionStep = () => {
    if (walkthroughIndex < walkthroughPositions.length - 1) {
      const nextIdx = walkthroughIndex + 1;
      setWalkthroughIndex(nextIdx);
      setBoardFen(walkthroughPositions[nextIdx]);
      soundManager.playMove();
    }
  };

  const handlePrevSolutionStep = () => {
    if (walkthroughIndex > 0) {
      const prevIdx = walkthroughIndex - 1;
      setWalkthroughIndex(prevIdx);
      setBoardFen(walkthroughPositions[prevIdx]);
      soundManager.playMove();
    }
  };

  // Player move execution handler
  const handleMovePlayed = (moveData: { from: string; to: string; promotion?: string; san: string }): boolean => {
    if (!isInteractive || isSolved) return false;

    const expectedSan = puzzle.solution[solutionStepIndex];

    // Helper: normalizes SAN for comparison (e.g. "Qxf7#" vs "Qxf7+", "Qe8" vs "Qe8+")
    const normalizeSan = (s: string) => s.replace(/[+#x]/g, '').trim();

    const isMatch =
      moveData.san === expectedSan ||
      normalizeSan(moveData.san) === normalizeSan(expectedSan);

    if (!isMatch) {
      // Wrong move played
      soundManager.playWrong();
      setWrongSquare(moveData.to);
      setTimeout(() => setWrongSquare(null), 800);

      setFeedbackMessage({
        text: `نقلة غير دقيقة (${moveData.san})! حاول مرة أخرى أو استخدم التلميح.`,
        type: 'error',
      });
      return false;
    }

    // Correct Move!
    const updatedChess = new Chess(boardFen);
    updatedChess.move({
      from: moveData.from as Square,
      to: moveData.to as Square,
      promotion: moveData.promotion || 'q',
    });

    const newFen = updatedChess.fen();
    setBoardFen(newFen);
    setPlayedMoves((prev) => [...prev, moveData.san]);

    // Clear hints
    setHintSquare(null);
    setHintTargetSquare(null);
    setHintMessage(null);
    setFeedbackMessage(null);

    const nextStep = solutionStepIndex + 1;
    setSolutionStepIndex(nextStep);

    // Check if puzzle is solved
    if (nextStep >= puzzle.solution.length) {
      // Puzzle completed!
      handlePuzzleSolved();
      return true;
    }

    // If opponent has a response move
    const opponentExpectedSan = puzzle.solution[nextStep];
    setFeedbackMessage({
      text: 'نقلة صحيحة وممتازة! خصمك يفكر في الرد...',
      type: 'success',
    });
    setIsInteractive(false);

    // Opponent plays automatically after 500ms
    setTimeout(() => {
      try {
        const oppChess = new Chess(newFen);
        const oppMoveRes = oppChess.move(opponentExpectedSan);

        if (oppMoveRes) {
          if (oppMoveRes.captured) {
            soundManager.playCapture();
          } else {
            soundManager.playMove();
          }
          if (oppChess.isCheck()) {
            soundManager.playCheck();
          }

          setBoardFen(oppChess.fen());
          setPlayedMoves((prev) => [...prev, oppMoveRes.san]);

          const stepAfterOpponent = nextStep + 1;
          setSolutionStepIndex(stepAfterOpponent);

          if (stepAfterOpponent >= puzzle.solution.length) {
            handlePuzzleSolved();
          } else {
            setIsInteractive(true);
            setFeedbackMessage({
              text: 'رد الخصم! ابحث عن النقلة الحاسمة التالية.',
              type: 'info',
            });
          }
        }
      } catch (err) {
        console.error('Error executing opponent move:', err);
        setIsInteractive(true);
      }
    }, 550);

    return true;
  };

  // Victory Handler
  const handlePuzzleSolved = () => {
    setIsSolved(true);
    setIsInteractive(false);
    soundManager.playSuccess();

    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#10B981', '#3B82F6', '#EC4899', '#8B5CF6'],
      });
    } catch {
      // Confetti fallback
    }

    setFeedbackMessage({
      text: '✓ رائع جداً! تم حل اللغز وإتقان التكتيك بنجاح!',
      type: 'success',
    });

    setStats((prev) => {
      const newStreak = prev.currentStreak + 1;
      return {
        ...prev,
        solvedCount: prev.solvedCount + 1,
        attemptedCount: prev.attemptedCount + 1,
        currentStreak: newStreak,
        bestStreak: Math.max(prev.bestStreak, newStreak),
        history: [
          {
            puzzleId: puzzle.id,
            title: puzzle.title,
            rating: puzzle.rating,
            solved: true,
            timestamp: Date.now(),
            timeTakenSeconds: elapsedSeconds,
          },
          ...prev.history.slice(0, 49),
        ],
      };
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500/30">
      {/* Top Navbar */}
      <header className="border-b border-slate-800/80 bg-slate-900/80 backdrop-blur-md sticky top-0 z-40 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          {/* Logo & Title */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-400 text-slate-950 flex items-center justify-center font-extrabold shadow-lg shadow-amber-500/20">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-extrabold text-sm md:text-base text-white tracking-tight leading-tight">
                مستكشف ألغاز الشطرنج التفاعلي
              </h1>
              <div className="text-[11px] text-slate-400 flex items-center gap-1.5 font-medium">
                <span className="text-emerald-400 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  <span>مجاني 100% بدون أي مفاتيح</span>
                </span>
                <span>·</span>
                <span>بحث حي في الويب</span>
              </div>
            </div>
          </div>

          {/* Header Controls */}
          <div className="flex items-center gap-2">
            <ThemeSelector currentThemeId={themeId} onSelectTheme={setThemeId} />

            <button
              onClick={() => setIsSearchOpen(true)}
              className="py-1.5 px-3 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Globe className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">البحث في الويب</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 lg:p-6 space-y-4">
        {/* Statistics Bar */}
        <StatsPanel stats={stats} elapsedSeconds={elapsedSeconds} />

        {/* Puzzle Header Details */}
        <PuzzleHeader puzzle={puzzle} isSolved={isSolved} stepIndex={solutionStepIndex} />

        {/* Board & Sidebar Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left Column: Interactive ChessBoard (Desktop: 7 cols) */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center w-full">
            <ChessBoard
              fen={boardFen}
              theme={BOARD_THEMES[themeId]}
              orientation={orientation}
              onMovePlayed={handleMovePlayed}
              hintSquare={hintSquare}
              hintTargetSquare={hintTargetSquare}
              wrongSquare={wrongSquare}
              isInteractive={isInteractive}
            />

            <div className="w-full max-w-[540px] flex items-center justify-between text-[11px] text-slate-500 pt-2 px-1">
              <span>اسحب القطعة أو انقر عليها ثم انقر على مربع الوصول</span>
              <span>{orientation === 'w' ? 'عرض رقعة الأبيض' : 'عرض رقعة الأسود'}</span>
            </div>
          </div>

          {/* Right Column: Controls & Feedback (Desktop: 5 cols) */}
          <div className="lg:col-span-5 space-y-4 w-full">
            <PuzzleControls
              onHint={handleHint}
              hintLevel={hintLevel}
              onReset={handleResetPuzzle}
              onNextWebPuzzle={handleFetchNextWebPuzzle}
              onOpenSearch={() => setIsSearchOpen(true)}
              onFlipBoard={() => setOrientation((prev) => (prev === 'w' ? 'b' : 'w'))}
              onToggleSound={handleToggleSound}
              isSoundEnabled={isSoundEnabled}
              onToggleSolution={handleToggleSolution}
              isShowingSolution={isShowingSolution}
              isLoadingNext={isLoadingNext}
              isSolved={isSolved}
              canNextSolutionStep={walkthroughIndex < walkthroughPositions.length - 1}
              canPrevSolutionStep={walkthroughIndex > 0}
              onNextSolutionStep={handleNextSolutionStep}
              onPrevSolutionStep={handlePrevSolutionStep}
            />

            <MoveHistory
              playedMoves={playedMoves}
              feedbackMessage={feedbackMessage}
              hintMessage={hintMessage}
              isSolved={isSolved}
            />
          </div>
        </div>
      </main>

      {/* Web Search Modal */}
      <WebSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectPuzzle={(selected) => loadNewPuzzle(selected)}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-4 text-center text-xs text-slate-500">
        <p>
          مستكشف ألغاز الشطرنج التفاعلي · مبني بتقنيات الويب الحديثة ومتصل بقواعد بيانات الشطرنج المفتوحة (Lichess &amp; Chess.com) · مجاني بالكامل وبدون أي مفاتيح API.
        </p>
      </footer>
    </div>
  );
}
